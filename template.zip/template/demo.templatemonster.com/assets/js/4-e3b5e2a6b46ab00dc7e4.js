/*! For license information please see 4-e3b5e2a6b46ab00dc7e4.js.LICENSE.txt */
"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
    [4, 228], {
        729: (t, e, r) => {
            r.d(e, {
                r: () => v
            });
            var n = r(4234),
                a = r(3081);

            function o(t) {
                let e, r, a, o, c, s, i, l, u, p, d, f, b, m, v, g, y, h, I, L, w, T = t[1].premium + "",
                    $ = t[1].saveNow + "";
                return {
                    c() {
                        e = (0, n.bGB)("button"), r = (0, n.DhX)(), a = (0, n.bGB)("div"), o = (0, n.bGB)("button"), c = (0, n.DhX)(), s = (0, n.bGB)("a"), i = (0, n.bGB)("div"), l = (0, n.bGB)("div"), l.innerHTML = '<span class="catalog-premium-popup-discount-number svelte-wnzymq">15</span> \n          <span class="catalog-premium-popup-discount-text svelte-wnzymq"><span>%</span> \n            <span>OFF</span></span>', u = (0, n.DhX)(), p = (0, n.bGB)("div"), d = (0, n.bGB)("span"), f = (0, n.fLW)(T), b = (0, n.DhX)(), m = (0, n.bGB)("span"), v = (0, n.fLW)(t[0]), g = (0, n.DhX)(), y = (0, n.bGB)("div"), h = (0, n.bGB)("button"), I = (0, n.fLW)($), (0, n.Ljt)(e, "class", "catalog-premium-popup-overlay svelte-wnzymq"), (0, n.Ljt)(o, "type", "button"), (0, n.Ljt)(o, "class", "catalog-premium-popup-close-btn svelte-wnzymq"), (0, n.Ljt)(l, "class", "catalog-premium-popup-discount svelte-wnzymq"), (0, n.Ljt)(p, "class", "catalog-premium-popup-title svelte-wnzymq"), (0, n.Ljt)(i, "class", "catalog-premium-popup-top svelte-wnzymq"), (0, n.Ljt)(h, "class", "btn btn_4 catalog-premium-popup-btn svelte-wnzymq"), (0, n.Ljt)(y, "class", "catalog-premium-popup-btn-container svelte-wnzymq"), (0, n.Ljt)(s, "href", t[2]), (0, n.Ljt)(s, "class", "catalog-premium-popup-content svelte-wnzymq"), (0, n.Ljt)(a, "class", "catalog-premium-popup svelte-wnzymq")
                    },
                    m(T, $) {
                        (0, n.$Tr)(T, e, $), (0, n.$Tr)(T, r, $), (0, n.$Tr)(T, a, $), (0, n.R3I)(a, o), (0, n.R3I)(a, c), (0, n.R3I)(a, s), (0, n.R3I)(s, i), (0, n.R3I)(i, l), (0, n.R3I)(i, u), (0, n.R3I)(i, p), (0, n.R3I)(p, d), (0, n.R3I)(d, f), (0, n.R3I)(p, b), (0, n.R3I)(p, m), (0, n.R3I)(m, v), (0, n.R3I)(s, g), (0, n.R3I)(s, y), (0, n.R3I)(y, h), (0, n.R3I)(h, I), L || (w = [(0, n.oLt)(e, "click", t[4]), (0, n.oLt)(o, "click", t[4])], L = !0)
                    },
                    p(t, e) {
                        2 & e && T !== (T = t[1].premium + "") && (0, n.rTO)(f, T), 1 & e && (0, n.rTO)(v, t[0]), 2 & e && $ !== ($ = t[1].saveNow + "") && (0, n.rTO)(I, $), 4 & e && (0, n.Ljt)(s, "href", t[2])
                    },
                    d(t) {
                        t && (0, n.ogt)(e), t && (0, n.ogt)(r), t && (0, n.ogt)(a), L = !1, (0, n.j7q)(w)
                    }
                }
            }

            function c(t) {
                let e, r = t[3] && o(t);
                return {
                    c() {
                        r && r.c(), e = (0, n.cSb)()
                    },
                    m(t, a) {
                        r && r.m(t, a), (0, n.$Tr)(t, e, a)
                    },
                    p(t, [n]) {
                        t[3] ? r ? r.p(t, n) : (r = o(t), r.c(), r.m(e.parentNode, e)) : r && (r.d(1), r = null)
                    },
                    i: n.ZTd,
                    o: n.ZTd,
                    d(t) {
                        r && r.d(t), t && (0, n.ogt)(e)
                    }
                }
            }

            function s(t, e, r) {
                let {
                    translates: n = {}
                } = e, {
                    productType: o = null
                } = e, {
                    url: c = null
                } = e, s = !0;
                return o = "HTML Website Templates" === o ? "HTML Templates" : o, t.$$set = t => {
                    "translates" in t && r(1, n = t.translates), "productType" in t && r(0, o = t.productType), "url" in t && r(2, c = t.url)
                }, [o, n, c, s, function() {
                    (0, a.d8)("nldPopup", 1, {
                        expires: 1
                    }), r(3, s = !1)
                }]
            }
            class i extends n.f_C {
                constructor(t) {
                    super(), (0, n.S1n)(this, t, s, c, n.N8, {
                        translates: 1,
                        productType: 0,
                        url: 2
                    })
                }
            }
            const l = i;
            var u = r(5980),
                p = r(5191),
                d = r(922);
            const f = {
                productAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var n = (0, d.fr)(t.target.dataset);
                                (0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("viewItemList", n)), e.unobserve(t.target), r.push(t.target.dataset)
                            }
                        })), r
                    }
                },
                authorNavigation: {
                    options: {
                        rootMargin: "-10% 0% -85% 0%"
                    },
                    callback: function(t) {
                        var e = document.querySelector(".floating-bar-tabs"),
                            r = document.querySelector(".author-tabs");
                        t.forEach((function(t) {
                            var n = t.target.querySelector(".anchor").id;
                            "author-intro" === n && (t.isIntersecting ? r.classList.remove("author-tabs_shadow") : r.classList.add("author-tabs_shadow")), t.isIntersecting && e.querySelectorAll(".floating-bar-tabs-link").forEach((function(t) {
                                t.getAttribute("href") === "#".concat(n) || t.getAttribute("data-href") === "#".concat(n) ? t.classList.add("floating-bar-tabs-link_active") : t.classList.remove("floating-bar-tabs-link_active")
                            }))
                        }))
                    }
                },
                productNavBar: {
                    options: {
                        rootMargin: "-8% 0% -85% 0%"
                    },
                    callback: function(t) {
                        var e = document.querySelectorAll(".product-nav-bar-tabs-link"),
                            r = document.querySelector(".floating-bar");
                        t.forEach((function(t) {
                            var n = t.target.querySelector(".anchor").id;
                            "tab-intro" === n && t.isIntersecting && r.classList.remove("floating-bar_visible"), t.isIntersecting && e.forEach((function(t) {
                                t.getAttribute("href") === "#".concat(n) || t.getAttribute("data-href") === "#".concat(n) ? (t.classList.add("product-nav-bar-tabs-link_active"), "tab-intro" !== n && r.classList.add("floating-bar_visible")) : t.classList.remove("product-nav-bar-tabs-link_active")
                            }))
                        }))
                    }
                },
                serviceNavBar: {},
                promotionAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            t.isIntersecting && ((0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("promotionView", t.target.dataset)), e.unobserve(t.target), r.push(t.target.dataset))
                        })), r
                    }
                },
                trackEventAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            t.isIntersecting && ((0, u.y)((0, p.c)("trackEvent", t.target.dataset)), e.unobserve(t.target), r.push(t.target.dataset))
                        })), r
                    }
                },
                hideProductLicenseDropdown: {
                    options: {
                        threshold: [1]
                    },
                    callback: function(t, e) {
                        t.forEach((function(t) {
                            if (!t.isIntersecting) {
                                var e = t.target.querySelector(".cart-modal-license-button_active"),
                                    r = t.target.querySelector(".cart-modal-license-container_active");
                                e && e.classList.add("cart-modal-license-button_hidden-dropdown"), r && r.classList.add("cart-modal-license-container_hidden-dropdown")
                            }
                        }))
                    }
                },
                recommendedServicesAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var n = t.target.dataset;
                                (0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("viewItemList", [n])), (0, u.y)((0, p.c)("cartOffer", {
                                    eventAction: "View",
                                    eventLabel: "".concat(n.item_id, " - ").concat(n.index, " - ").concat(n.type)
                                })), e.unobserve(t.target), r.push(t.target.dataset)
                            }
                        })), r
                    }
                },
                showBanner: {
                    options: {
                        threshold: [1]
                    },
                    callback: function(t, e) {
                        t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var r = document.querySelector("#premium-sale-popup"),
                                    n = (0, a.ej)("nld"),
                                    o = (0, a.ej)("nldPopup");
                                e.unobserve(t.target), !r || n || o || setTimeout((function() {
                                    new l({
                                        target: r,
                                        props: {
                                            productType: r.getAttribute("data-product-type"),
                                            url: r.getAttribute("data-url"),
                                            translates: JSON.parse(r.getAttribute("data-translates"))
                                        }
                                    })
                                }), 1e3)
                            }
                        }))
                    }
                }
            };

            function b(t, e) {
                var r = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!r) {
                    if (Array.isArray(t) || (r = function(t, e) {
                            if (!t) return;
                            if ("string" == typeof t) return m(t, e);
                            var r = Object.prototype.toString.call(t).slice(8, -1);
                            "Object" === r && t.constructor && (r = t.constructor.name);
                            if ("Map" === r || "Set" === r) return Array.from(t);
                            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return m(t, e)
                        }(t)) || e && t && "number" == typeof t.length) {
                        r && (t = r);
                        var n = 0,
                            a = function() {};
                        return {
                            s: a,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                }
                            },
                            e: function(t) {
                                throw t
                            },
                            f: a
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var o, c = !0,
                    s = !1;
                return {
                    s: function() {
                        r = r.call(t)
                    },
                    n: function() {
                        var t = r.next();
                        return c = t.done, t
                    },
                    e: function(t) {
                        s = !0, o = t
                    },
                    f: function() {
                        try {
                            c || null == r.return || r.return()
                        } finally {
                            if (s) throw o
                        }
                    }
                }
            }

            function m(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
                return n
            }

            function v(t) {
                if (t) {
                    var e = JSON.parse(t.getAttribute("data-visibility-observer")),
                        r = t.querySelectorAll(e.selector),
                        n = f[e.preset],
                        a = n.callback,
                        o = n.options;
                    if (!r.length || !a || !o) return;
                    var c, s = new IntersectionObserver(a, o),
                        i = b(r);
                    try {
                        for (i.s(); !(c = i.n()).done;) {
                            var l = c.value;
                            s.observe(l)
                        }
                    } catch (t) {
                        i.e(t)
                    } finally {
                        i.f()
                    }
                }
            }(0, a.Fi)((function() {
                document.querySelectorAll("[data-visibility-observer]").forEach((function(t) {
                    return v(t)
                }))
            }))
        },
        1740: (t, e, r) => {
            r.r(e), r.d(e, {
                default: () => f
            });
            var n = r(4234),
                a = r(6943),
                o = r(5980),
                c = r(3081),
                s = r(5191),
                i = r(7312);

            function l(t) {
                let e, r;
                return e = new i.Z({
                    props: {
                        cartTranslations: t[0],
                        cartItems: t[2]
                    }
                }), e.$on("closeCartModal", t[5]), {
                    c() {
                        (0, n.YCL)(e.$$.fragment)
                    },
                    m(t, a) {
                        (0, n.yef)(e, t, a), r = !0
                    },
                    p(t, r) {
                        const n = {};
                        1 & r && (n.cartTranslations = t[0]), 4 & r && (n.cartItems = t[2]), e.$set(n)
                    },
                    i(t) {
                        r || ((0, n.Ui)(e.$$.fragment, t), r = !0)
                    },
                    o(t) {
                        (0, n.etI)(e.$$.fragment, t), r = !1
                    },
                    d(t) {
                        (0, n.vpE)(e, t)
                    }
                }
            }

            function u(t) {
                let e, r, a, o, c, s, i = t[3] && l(t);
                return {
                    c() {
                        e = (0, n.bGB)("button"), r = (0, n.DhX)(), i && i.c(), a = (0, n.cSb)(), (0, n.Ljt)(e, "type", "button"), (0, n.Ljt)(e, "aria-label", "cart"), (0, n.Ljt)(e, "class", "cart-button-modal-opener"), e.disabled = t[1]
                    },
                    m(l, u) {
                        (0, n.$Tr)(l, e, u), (0, n.$Tr)(l, r, u), i && i.m(l, u), (0, n.$Tr)(l, a, u), o = !0, c || (s = (0, n.oLt)(e, "click", t[4]), c = !0)
                    },
                    p(t, [r]) {
                        (!o || 2 & r) && (e.disabled = t[1]), t[3] ? i ? (i.p(t, r), 8 & r && (0, n.Ui)(i, 1)) : (i = l(t), i.c(), (0, n.Ui)(i, 1), i.m(a.parentNode, a)) : i && ((0, n.dvw)(), (0, n.etI)(i, 1, 1, (() => {
                            i = null
                        })), (0, n.gbL)())
                    },
                    i(t) {
                        o || ((0, n.Ui)(i), o = !0)
                    },
                    o(t) {
                        (0, n.etI)(i), o = !1
                    },
                    d(t) {
                        t && (0, n.ogt)(e), t && (0, n.ogt)(r), i && i.d(t), t && (0, n.ogt)(a), c = !1, s()
                    }
                }
            }

            function p(t, e, r) {
                let i, l, u;
                (0, n.FIv)(t, a.Z, (t => r(6, u = t)));
                let {
                    cartTranslations: p
                } = e, d = !1;
                return t.$$set = t => {
                    "cartTranslations" in t && r(0, p = t.cartTranslations)
                }, t.$$.update = () => {
                    64 & t.$$.dirty && r(3, i = u.isCartModalOpen), 64 & t.$$.dirty && r(2, l = u.cartModal.items)
                }, [p, d, l, i, function() {
                    r(1, d = !0), (0, c.To)((() => {
                        a.Z.setIsCartModalOpen(!0), (0, o.y)((0, s.c)("openCartPopup", {
                            label: "Open cart"
                        })), r(1, d = !1)
                    }))
                }, function() {
                    (0, c.To)((() => {
                        a.Z.setIsCartModalOpen(!1)
                    }))
                }, u]
            }
            class d extends n.f_C {
                constructor(t) {
                    super(), (0, n.S1n)(this, t, p, u, n.N8, {
                        cartTranslations: 0
                    })
                }
            }
            const f = d
        }
    }
]);