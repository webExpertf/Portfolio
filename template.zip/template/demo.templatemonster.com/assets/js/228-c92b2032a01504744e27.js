/*! For license information please see 228-c92b2032a01504744e27.js.LICENSE.txt */
"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
    [228], {
        729: (t, e, r) => {
            r.d(e, {
                r: () => m
            });
            var n = r(4234),
                a = r(3081);

            function o(t) {
                let e, r, a, o, c, i, s, l, u, p, d, f, b, v, m, g, h, y, L, w, I, q = t[1].premium + "",
                    k = t[1].saveNow + "";
                return {
                    c() {
                        e = (0, n.bGB)("button"), r = (0, n.DhX)(), a = (0, n.bGB)("div"), o = (0, n.bGB)("button"), c = (0, n.DhX)(), i = (0, n.bGB)("a"), s = (0, n.bGB)("div"), l = (0, n.bGB)("div"), l.innerHTML = '<span class="catalog-premium-popup-discount-number svelte-wnzymq">15</span> \n          <span class="catalog-premium-popup-discount-text svelte-wnzymq"><span>%</span> \n            <span>OFF</span></span>', u = (0, n.DhX)(), p = (0, n.bGB)("div"), d = (0, n.bGB)("span"), f = (0, n.fLW)(q), b = (0, n.DhX)(), v = (0, n.bGB)("span"), m = (0, n.fLW)(t[0]), g = (0, n.DhX)(), h = (0, n.bGB)("div"), y = (0, n.bGB)("button"), L = (0, n.fLW)(k), (0, n.Ljt)(e, "class", "catalog-premium-popup-overlay svelte-wnzymq"), (0, n.Ljt)(o, "type", "button"), (0, n.Ljt)(o, "class", "catalog-premium-popup-close-btn svelte-wnzymq"), (0, n.Ljt)(l, "class", "catalog-premium-popup-discount svelte-wnzymq"), (0, n.Ljt)(p, "class", "catalog-premium-popup-title svelte-wnzymq"), (0, n.Ljt)(s, "class", "catalog-premium-popup-top svelte-wnzymq"), (0, n.Ljt)(y, "class", "btn btn_4 catalog-premium-popup-btn svelte-wnzymq"), (0, n.Ljt)(h, "class", "catalog-premium-popup-btn-container svelte-wnzymq"), (0, n.Ljt)(i, "href", t[2]), (0, n.Ljt)(i, "class", "catalog-premium-popup-content svelte-wnzymq"), (0, n.Ljt)(a, "class", "catalog-premium-popup svelte-wnzymq")
                    },
                    m(q, k) {
                        (0, n.$Tr)(q, e, k), (0, n.$Tr)(q, r, k), (0, n.$Tr)(q, a, k), (0, n.R3I)(a, o), (0, n.R3I)(a, c), (0, n.R3I)(a, i), (0, n.R3I)(i, s), (0, n.R3I)(s, l), (0, n.R3I)(s, u), (0, n.R3I)(s, p), (0, n.R3I)(p, d), (0, n.R3I)(d, f), (0, n.R3I)(p, b), (0, n.R3I)(p, v), (0, n.R3I)(v, m), (0, n.R3I)(i, g), (0, n.R3I)(i, h), (0, n.R3I)(h, y), (0, n.R3I)(y, L), w || (I = [(0, n.oLt)(e, "click", t[4]), (0, n.oLt)(o, "click", t[4])], w = !0)
                    },
                    p(t, e) {
                        2 & e && q !== (q = t[1].premium + "") && (0, n.rTO)(f, q), 1 & e && (0, n.rTO)(m, t[0]), 2 & e && k !== (k = t[1].saveNow + "") && (0, n.rTO)(L, k), 4 & e && (0, n.Ljt)(i, "href", t[2])
                    },
                    d(t) {
                        t && (0, n.ogt)(e), t && (0, n.ogt)(r), t && (0, n.ogt)(a), w = !1, (0, n.j7q)(I)
                    }
                }
            }

            function c(t) {
                let e, r = t[3] && o(t);
                return {
                    c() {
                        r && r.c(), e = (0, n.cSb)()
                    },
                    m(t, a) {
                        r && r.m(t, a), (0, n.$Tr)(t, e, a)
                    },
                    p(t, [n]) {
                        t[3] ? r ? r.p(t, n) : (r = o(t), r.c(), r.m(e.parentNode, e)) : r && (r.d(1), r = null)
                    },
                    i: n.ZTd,
                    o: n.ZTd,
                    d(t) {
                        r && r.d(t), t && (0, n.ogt)(e)
                    }
                }
            }

            function i(t, e, r) {
                let {
                    translates: n = {}
                } = e, {
                    productType: o = null
                } = e, {
                    url: c = null
                } = e, i = !0;
                return o = "HTML Website Templates" === o ? "HTML Templates" : o, t.$$set = t => {
                    "translates" in t && r(1, n = t.translates), "productType" in t && r(0, o = t.productType), "url" in t && r(2, c = t.url)
                }, [o, n, c, i, function() {
                    (0, a.d8)("nldPopup", 1, {
                        expires: 1
                    }), r(3, i = !1)
                }]
            }
            class s extends n.f_C {
                constructor(t) {
                    super(), (0, n.S1n)(this, t, i, c, n.N8, {
                        translates: 1,
                        productType: 0,
                        url: 2
                    })
                }
            }
            const l = s;
            var u = r(5980),
                p = r(5191),
                d = r(922);
            const f = {
                productAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var n = (0, d.fr)(t.target.dataset);
                                (0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("viewItemList", n)), e.unobserve(t.target), r.push(t.target.dataset)
                            }
                        })), r
                    }
                },
                authorNavigation: {
                    options: {
                        rootMargin: "-10% 0% -85% 0%"
                    },
                    callback: function(t) {
                        var e = document.querySelector(".floating-bar-tabs"),
                            r = document.querySelector(".author-tabs");
                        t.forEach((function(t) {
                            var n = t.target.querySelector(".anchor").id;
                            "author-intro" === n && (t.isIntersecting ? r.classList.remove("author-tabs_shadow") : r.classList.add("author-tabs_shadow")), t.isIntersecting && e.querySelectorAll(".floating-bar-tabs-link").forEach((function(t) {
                                t.getAttribute("href") === "#".concat(n) || t.getAttribute("data-href") === "#".concat(n) ? t.classList.add("floating-bar-tabs-link_active") : t.classList.remove("floating-bar-tabs-link_active")
                            }))
                        }))
                    }
                },
                productNavBar: {
                    options: {
                        rootMargin: "-8% 0% -85% 0%"
                    },
                    callback: function(t) {
                        var e = document.querySelectorAll(".product-nav-bar-tabs-link"),
                            r = document.querySelector(".floating-bar");
                        t.forEach((function(t) {
                            var n = t.target.querySelector(".anchor").id;
                            "tab-intro" === n && t.isIntersecting && r.classList.remove("floating-bar_visible"), t.isIntersecting && e.forEach((function(t) {
                                t.getAttribute("href") === "#".concat(n) || t.getAttribute("data-href") === "#".concat(n) ? (t.classList.add("product-nav-bar-tabs-link_active"), "tab-intro" !== n && r.classList.add("floating-bar_visible")) : t.classList.remove("product-nav-bar-tabs-link_active")
                            }))
                        }))
                    }
                },
                serviceNavBar: {},
                promotionAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            t.isIntersecting && ((0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("promotionView", t.target.dataset)), e.unobserve(t.target), r.push(t.target.dataset))
                        })), r
                    }
                },
                trackEventAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            t.isIntersecting && ((0, u.y)((0, p.c)("trackEvent", t.target.dataset)), e.unobserve(t.target), r.push(t.target.dataset))
                        })), r
                    }
                },
                hideProductLicenseDropdown: {
                    options: {
                        threshold: [1]
                    },
                    callback: function(t, e) {
                        t.forEach((function(t) {
                            if (!t.isIntersecting) {
                                var e = t.target.querySelector(".cart-modal-license-button_active"),
                                    r = t.target.querySelector(".cart-modal-license-container_active");
                                e && e.classList.add("cart-modal-license-button_hidden-dropdown"), r && r.classList.add("cart-modal-license-container_hidden-dropdown")
                            }
                        }))
                    }
                },
                recommendedServicesAnalytics: {
                    options: {
                        threshold: [.2]
                    },
                    callback: function(t, e) {
                        var r = [];
                        return t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var n = t.target.dataset;
                                (0, u.y)((0, p.c)("clear")), (0, u.y)((0, p.c)("viewItemList", [n])), (0, u.y)((0, p.c)("cartOffer", {
                                    eventAction: "View",
                                    eventLabel: "".concat(n.item_id, " - ").concat(n.index, " - ").concat(n.type)
                                })), e.unobserve(t.target), r.push(t.target.dataset)
                            }
                        })), r
                    }
                },
                showBanner: {
                    options: {
                        threshold: [1]
                    },
                    callback: function(t, e) {
                        t.forEach((function(t) {
                            if (t.isIntersecting) {
                                var r = document.querySelector("#premium-sale-popup"),
                                    n = (0, a.ej)("nld"),
                                    o = (0, a.ej)("nldPopup");
                                e.unobserve(t.target), !r || n || o || setTimeout((function() {
                                    new l({
                                        target: r,
                                        props: {
                                            productType: r.getAttribute("data-product-type"),
                                            url: r.getAttribute("data-url"),
                                            translates: JSON.parse(r.getAttribute("data-translates"))
                                        }
                                    })
                                }), 1e3)
                            }
                        }))
                    }
                }
            };

            function b(t, e) {
                var r = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!r) {
                    if (Array.isArray(t) || (r = function(t, e) {
                            if (!t) return;
                            if ("string" == typeof t) return v(t, e);
                            var r = Object.prototype.toString.call(t).slice(8, -1);
                            "Object" === r && t.constructor && (r = t.constructor.name);
                            if ("Map" === r || "Set" === r) return Array.from(t);
                            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return v(t, e)
                        }(t)) || e && t && "number" == typeof t.length) {
                        r && (t = r);
                        var n = 0,
                            a = function() {};
                        return {
                            s: a,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                }
                            },
                            e: function(t) {
                                throw t
                            },
                            f: a
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var o, c = !0,
                    i = !1;
                return {
                    s: function() {
                        r = r.call(t)
                    },
                    n: function() {
                        var t = r.next();
                        return c = t.done, t
                    },
                    e: function(t) {
                        i = !0, o = t
                    },
                    f: function() {
                        try {
                            c || null == r.return || r.return()
                        } finally {
                            if (i) throw o
                        }
                    }
                }
            }

            function v(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
                return n
            }

            function m(t) {
                if (t) {
                    var e = JSON.parse(t.getAttribute("data-visibility-observer")),
                        r = t.querySelectorAll(e.selector),
                        n = f[e.preset],
                        a = n.callback,
                        o = n.options;
                    if (!r.length || !a || !o) return;
                    var c, i = new IntersectionObserver(a, o),
                        s = b(r);
                    try {
                        for (s.s(); !(c = s.n()).done;) {
                            var l = c.value;
                            i.observe(l)
                        }
                    } catch (t) {
                        s.e(t)
                    } finally {
                        s.f()
                    }
                }
            }(0, a.Fi)((function() {
                document.querySelectorAll("[data-visibility-observer]").forEach((function(t) {
                    return m(t)
                }))
            }))
        }
    }
]);